import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static java.lang.Thread.sleep;


public class Demo {

    public static WebDriver driver;
    public static void main(String[] args) throws InterruptedException {

       System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://mvnrepository.com/");   
        sleep(5000);
        System.out.println("Suman");
        driver.quit();

    }

}