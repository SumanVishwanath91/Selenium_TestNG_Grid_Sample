
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class multiBrowsers extends TestNG{

    WebDriver driver;
    String url = "https://www.selenium.dev/";

    @BeforeTest
    @Parameters({"browser"})
    public void setup(String browser) throws Exception {
       if (browser.equalsIgnoreCase("firefox")) {
           System.setProperty("webdriver.gecko.driver", "src/drivers/geckodriver.exe");
           System.setProperty("webdriver.firefox.bin", "C:/Mozilla/firefox.exe");
           driver = new FirefoxDriver();


       } else if (browser.equalsIgnoreCase("chrome")) {
           System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
           driver = new ChromeDriver();
       }
           else if (browser.equalsIgnoreCase("ie")) {
               System.setProperty("webdriver.ie.driver", "src/drivers/IEdriverServer.exe");
               driver = new InternetExplorerDriver();
       }  else {
            throw new Exception("Incorrect Browser");
       }
        // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
}
    @Test
    public void afterAccess() {
        driver.get(url);
        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl,url);
        driver.quit();
    }

}