import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class TestNG extends Demo {
    WebDriver driver;
    String url = "https://www.selenium.dev/";

    @BeforeClass
    public void testSetup() {
        System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

    }

    @BeforeMethod
    public void openBrowser() {

       driver.get(url);

    }

  @Test(description = "This method validates the sign up functionality")
    public void product() {
        driver.findElement(By.cssSelector("#main_navbar > ul > li:nth-child(2) > a > span")).click();

    }

   @Test
    public void postAccess() {
        String currentUrl = driver.getCurrentUrl();
        System.out.println(currentUrl);
        Assert.assertEquals(currentUrl,url);

    }

    @AfterClass
    public void afterClass() {
        driver.quit();
    }

}